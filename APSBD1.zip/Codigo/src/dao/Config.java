package dao;

/**
 *
 * @author André Schwerz
 */
public class Config {
    public static final String URL = "jdbc:mysql://localhost/apbd";
    public static final String LOGIN = "root";
    public static final String PASSWORD = "root"; 
}